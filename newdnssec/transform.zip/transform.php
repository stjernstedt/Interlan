<?php

	$datum = "";
	while( !feof(STDIN) ){
		$datum = trim(fgets(STDIN));
	}


	/*
		***********
		* Helpers *
		***********
	*/
	function formatEmail($email){
		if($email == "") return "";
		$email = str_replace("\\.", "�", $email);

		if( strpos($email, '\\@') > 0){
			$email = str_replace("\\@", " [at] ", $email);
		}
		else{
			$firstDot = strpos($email, '.');
			$email = substr($email, 0, $firstDot) . " [at] " . substr($email, $firstDot + 1);
		}

		return str_replace("�", ".", $email);
	}

	function removeEndingDot($str){
		if( strlen($str) > 0 && $str[ strlen($str)-1 ] == '.'){
			return substr($str, 0, -1);
		}
		return $str;
	}


	/*
		*****************
		* Main methods  *
		*****************
	*/

	function createOutput($dateOfIntrest){
		$nl = "\n";

		// header
		echo '{' . $nl;
		echo '	"municipalities": {' . $nl;
		echo '		"municipality": [' . $nl;


		$csv = file_get_contents("komdom.csv");
		$rows = str_getcsv( $csv, "\n");
		$lastRow = count($rows);

		// content
		for( $i=0; $i<$lastRow; $i++){

			$row = str_getcsv( $rows[$i], ";" );

			$kommunkod = $row[0];
			$namn = htmlentities($row[1]);
			$url = $row[2];

			echo '			{' . $nl;
			echo formatSingleKommun($kommunkod, $namn, $url, $dateOfIntrest);
			echo '			}';

			if( $i < ($lastRow - 1) ) echo ",";
			echo $nl;
		}

		// footer
		echo '		]' . $nl;
		echo '	}' . $nl;
		echo '}' . $nl;

	}


	function formatSingleKommun($kod, $namn, $host, $dateOfIntrest){
		$nl = "\n";

		$tab1 = "\t\t\t\t";
		$tab2 = "\t\t\t\t\t";
		$back = '';

		$back .= $tab1 . '"knnr": "' . $kod . '",' . $nl;
		$back .= $tab1 . '"name": "' . $namn . '",' . $nl;
		$back .= $tab1 . '"url": "' . $host . '",' . $nl;

		$back .= getKommunData($host, $dateOfIntrest);

		return $back;
	}


	function getKommunData($host, $dateOfIntrest){

		$back = '';
		$nl = "\n";

		$tab1 = "\t\t\t\t";
		$tab2 = "\t\t\t\t\t";

		$data = file_get_contents("ex.txt"); //exec("n�tt " . $host . ' ' . $dateOfIntrest);
		$rows = str_getcsv( $data, "\n");
		$maxRows = count($rows);
/*
	Exempel p� inneh�ll:

		root.ale.se.,1,1,0,1,0
		dnslist
		ystad.dns.swip.net.
		dist.ale.se.
		errorlist
		4.49 fel med n�got
		4.50 fel med n�tt annat
		warninglist
		1.3 inte bra men n�stan
*/

		$outmode = 0;

		$arrDns = array();
		$arrErr = array();
		$arrWarn = array();

		for($i=0; $i<$maxRows; $i++){

			$ln = trim($rows[$i]);

			if( $i == 0 ){
				$items = str_getcsv( $ln, "," );

				$back .= $tab1 . '"contact": "' . formatEmail($items[0]) . '",' . $nl;
				$back .= $tab1 . '"dnsSecSigned": ' . ($items[1]=='1'? 'true' : 'false') . ',' . $nl;
				$back .= $tab1 . '"isRecursive": ' 	. ($items[2]=='1'? 'true' : 'false') . ',' . $nl;
				$back .= $tab1 . '"ipWww": ' 		. ($items[3]=='1'? 'true' : 'false') . ',' . $nl;
				$back .= $tab1 . '"ipDns": ' 		. ($items[4]=='1'? 'true' : 'false') . ',' . $nl;
				$back .= $tab1 . '"ipMail": ' 		. ($items[5]=='1'? 'true' : 'false') . ',' . $nl;
			}

			if($ln == "dnslist"){
				$outmode = 1;
				continue;
			}
			else if($ln == "errorlist"){
				$outmode = 2;
				continue;
			}
			else if($ln == "warninglist"){
				$outmode = 3;
				continue;
			}

			switch($outmode){
				case 1:
						array_push($arrDns, $ln);
						break;
				case 2:
						array_push($arrErr, $ln);
						break;
				case 3:
						array_push($arrWarn, $ln);
						break;
			}

		}//end for

		$back .= $tab1 . '"dnsList": [' . $nl;
		$maxRows = count($arrDns);
		for($i=0; $i<$maxRows; $i++){
			$back .= $tab2 . '{"name": "' . $arrDns[$i] . '"}';
			if( $i < $maxRows - 1) $back .= ',';
			$back .= $nl;
		}
		$back .= $tab1 . '],' . $nl;

		$back .= $tab1 . '"errorlist": [' . $nl;
		$maxRows = count($arrErr);
		for($i=0; $i<$maxRows; $i++){
			$back .= $tab2 . '{"description": "' . $arrErr[$i] . '"}';
			if( $i < $maxRows - 1) $back .= ',';
			$back .= $nl;
		}
		$back .= $tab1 . '],' . $nl;

		$back .= $tab1 . '"warninglist": [' . $nl;
		$maxRows = count($arrWarn);
		for($i=0; $i<$maxRows; $i++){
			$back .= $tab2 . '{"description": "' . $arrWarn[$i] . '"}';
			if( $i < $maxRows - 1) $back .= ',';
			$back .= $nl;
		}
		$back .= $tab1 . ']' . $nl;


		return $back;
	}


	// START METHOD:
	createOutput($datum);

?>