Information
	Utvecklat av 
	* Interlan Gefle AB (www.interlan.se) 
	* YouKnowWhat AB (www.youknowwhat.se)

Installation
	Inneh�llet i mappen source placeras p� er webbserver.
	Anropa d�refter sidan maps.php via webbl�saren.
	
	Det finns data f�r ett datum i mappen data. Detta g�r 
	att enbart 2012-03-18 kommer presenteras.
	
	All generering av presentation (polygoner och status)
	sker med hj�lp av json-filer som i sin tur genererats 
	av script som i det h�r fallet t.ex parsar resultat 
	fr�n dnscheck och h�mtar error och waringsrader och 
	d�refter skapar json-filerna.
	
Om filerna
	* maps.php - presenterar karta
	* maps.js.php - hanterar polygondata samt status/kommun
	* liten.json - polygondata
	* lang.php - �vers�ttningshantering
	* ajax-loader (1).gif - visar status under v�ntan
	* css/ * - utseende f�r gr�nssnitt
	* js/ * - jquery f�r enklare dhtml
	* data/ * - status / kommun f�r 2012-03-18
		
Serverkrav
	php
	
	